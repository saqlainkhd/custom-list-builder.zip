
// wait until the page and jquery is loaded before running the code
jQuery(document).ready(function($)
{

	// setup wp ajax url
	var wp_Ajax_url = document.location.protocol + '//' + document.location.host + "/wordpress/wp-admin/admin-ajax.php";


	// stop our admin menu for  collapsing
	if( $('body[class*=" slb_"]').length || $('body[class*=" post-type-slb_"]').length )
	{

		//alert('working');

		$slb_menu_li = $('#toplevel_page_slb_dashboard_admin_page');

		$slb_menu_li
		.removeClass('wp-not-current-submenu')
		.addClass('wp-has-current-submenu')
		.addClass('wp-menu-open');

		$('a:first',$slb_menu_li)
		.removeClass('wp-not-current-submenu')
		.addClass('wp-has-submenu')
		.addClass('wp-has-current-submenu')
		.addClass('wp-menu-open');

	}

	// wp uploader 
	// this adds wordpress's file uploader to specially formatted html div.wp-uploader
	// here's an example of what the html should like this.. 

	/*
		<div class="wp-uploader">
			<input type="text" name="slb_import_file" class="file-url regular-text"  accept="csv" />
			<input type="hidden" name="slb_import_file_id" class="file-id" value="0" />
			<input type="button" name="upload-btn" class="upload-btn button-secondary" value="Upload" />
		</div>
	*/

	$('.wp-uploader').each(function(){
		$uploader = $(this);

		$('.upload-btn',$uploader).click(function(e){
			e.preventDefault();

			var file = wp.media({
				title : 'upload',

				// multiple: true if you want to upload multiple files at once
				multiple : false

			}).open()
			.on('select', function(e){

				// this will return the selected image from the media uploader , the result is an object
				var uploaded_file = file.state().get('selection').first();

				// we convert uploaded_image to json object to make accessing it easier
				// ouput to the console upload_image
				var file_url = uploaded_file.attributes.url;
				var file_id = uploaded_file.id;

				if($('.file-url', $uploader).attr('accept') !== undefined)
				{
					var filetype = $('.file-url', $uploader).attr('accept');

					if(filetype !== uploaded_file.attributes.subtype)
					{
							$('.upload-text', $uploader).val('');
							alert("A File Must be a type of " + filetype);
					}
					else{

							// Let's assign the url value to the input field
							$('.file-url',$uploader).val(file_url).trigger('change');
							$('.file-id',$uploader).val(file_id).trigger('change');
					}

				}


			});
		});
	});

	// setup variables to store our import forms JQuery objects
	$import_form_1 = $('#import_form_1', '#import_subscribers');
	$import_form_2 = $('#import_form_2', '#import_subscribers');

	// this event is triggered when import_form_1 file is selected
	$('.file-id',$import_form_1).bind('change',function(){

		//alert('a csv File has been Added Successfuly');

		// get the form data and serialize it
		var form_1_data = $import_form_1.serialize();

		//console.log(form_1_data);


		// setup form_1 action url 
		var form_1_action_url = wp_Ajax_url + '?action=slb_parse_import_csv';

		// send the file to php processing..
		$.ajax({
			url : form_1_action_url,
			method: 'post',
			datatype: 'json',
			data: form_1_data,
			success: function(response)
					{

						//console.log(response);
						response = $.parseJSON(response);

						if(response.status == 1)
						{
							// get return html
							$return_html = slb_get_form_2_html(response.data);

							// update .slb-dynamic-content with the new retun html
							$('.slb-dynamic-content',$import_form_2).html($return_html);

							$import_form_2.show();

						}
						else
						{
							// reset form 1's inputs
							$('.file-id',$import_form_1).val('0');
							$('.file-url',$import_form_1).val('');

							$import_form_2.hide();
							alert(response.message);
							
						}
					}

		});
	});

	

		




	


	// for toggling all subcriber data on and off 
	$(document).on('click','#import_subscribers #import_form_2 .check-all',function(){

		// see if a toggle is checked 
		var checked = $(this)[0].checked;

		// if our toggle is checked
		if(checked)
		{
			// trigger click on all inputs not checked 
			$('[name="slb_import_rows[]"]:not(:checked)',$import_form_2).trigger('click');

		}
		else
		{
			// trigger click on all inputs checked 
			$('[name="slb_import_rows[]"]:checked',$import_form_2).trigger('click');
		}

	});

	// check if our form 2 valid on all change events
	//  show and hide elements accordingly
		$(document).on("change","#import_subscribers #import_form_2 .slb-input",function(){
				//alert('done');
			setTimeout(function(){
			
				console.log(slb_form_2_is_valid());

				if(slb_form_2_is_valid())
				{
					$('.show-only-on-valid',$import_form_2).show();
				}
				else
				{
					
					$('.show-only-on-valid',$import_form_2).hide();
				}

			},100);
		});
	

	// hint: this is our ajax form handler for our import subscribers form #2
	$(document).on('submit','#import_subscribers #import_form_2' , function()
	{

		// setup url
		var form_2_action_url = wp_Ajax_url + '?action=slb_import_subscribers';

		// serialize form data
		var form_2_data = $import_form_2.serialize();

		$.post({
			url: form_2_action_url,
			method: 'post',
			datatype: 'json',
			data: form_2_data,
			success: function(response)
					{
						response = $.parseJSON(response);
						if(response.status == 1)
						{
							// reset import form
							$('.slb-dynamic-content').html('');
							$('.show-only-on-valid',$import_form_2).hide();
							$('.file-url',$import_form_1).val('');
							$('.file-id',$import_form_1).val(0);

							alert(response.message);

						}
						else
						{

							var msg = response.message + '\n' + response.error + '\n';
							$.each(response.errors, function(key,value){
								msg += '\n';
								msg += '- ' + value;
							});

							alert(msg);
						}
					}
				});

	
			return false;

	});




	// hint: this function return custom html for import form 2
	function slb_get_form_2_html(subscribers)
	{
		// count the no of columns we have in our subscriber data 
		var columns = Object.keys(subscribers[0]).length;

		var return_html = '';

		// prepare select html 
		var select_fname = slb_get_selector('slb_fname_column',subscribers);
		var select_lname = slb_get_selector('slb_lname_column',subscribers);
		var select_email = slb_get_selector('slb_email_column',subscribers);

		// build assign html
		var assign_html = '' +
						  '<p><label style="margin-right: 16px;">First Name</label> '+ select_fname  + '</p>' +
						  '<p><label style="margin-right: 16px;">Last Name</label> '+ select_lname  + '</p>' + 
						  '<p><label style="margin-right: 50px;">Email</label>  '+ select_email  + '</p>';

		//console.log(assign_html);

		// build row 1
		var row_1 = slb_get_form_table_row('Assign Data column', assign_html);
		return_html += row_1;

		//console.log(return_html);

		// build our data table
		var table = '<table class="wp-list-table fixed widefat stripped"><thead>';

		var tr = '<tr>';
		var th = '<th scope="col" class="manage-column check-column" > <label><input type="checkbox" class="check-all slb-input" /></label></th>';

		tr += th;

		var column_id = 0;

		$.each(subscribers[0] , function(key,value){
			column_id++;
			var th = '<th scope="col">' + key +'</th>';

			tr += th;
		});
		
		tr += '</tr>';

		table += tr +'</thead> <tbody id="the-list">';

		var row_id = 0;

		//console.log(table);

		// loop over all the subscriber 
		$.each(subscribers,function(index,subscriber){

				row_id++;

				var tr = '<tr>';

				// add our first table cell
				var th = '<th scope="row" class=" check-column"><input type="checkbox" id="cb-select-'+ row_id +'" name="slb_import_rows[]" class="slb-input" value="' + row_id +'" /></th>';
				tr += th;

				var column_id = 0;

				// loop over all the data column in this subscriber
				$.each(subscriber, function(key,value){

					column_id++;

					// setup a fieldname for our checkbox
					var fieldname = 's_'+ row_id +'_'+ column_id;

					// create the html for our table cell 
					var td = '<td>'+ value + '<input type="hidden" name="'+ fieldname +'" class="slb-input" value="'+ value +'"></td>';

					tr += td;
				});

				tr += '</tr>';

				table += tr;
		});

		table += '</tbody></table>';

		// build row 2 html and append our new table to it
		var row_2 = slb_get_form_table_row('select subscribers', table , 'Please Select all the subscribers you\'d like to import');

		//console.log(return_html);
		return_html += row_2;

		//console.log(return_html);

		

		// return the html as jquery object
		return $(return_html);

	}


	// hint: this function returns custom select html with the subscriber data header column as options
	function slb_get_selector(input_id , subscribers){

		// setup our return variable 
		var select  = '<select name="' + input_id + '" class="slb-input" > ';

		var column_id = 0;

		// setup our first option variable 
		var option = '<option value=""> -- Select One -- </option>';





		// add our first option to our select html;
		select += option;

		//console.log(subscribers[0]);
		$.each(subscribers[0],function(key,value){
			
			column_id++;

			// create our optional html

			var options  = '<option value="'+ column_id +'"> '+ column_id +'. '+ key +'</option>';

			select += options;
			//console.log('working');
		});


		select += '</select>';

		return select;

	}


	// hint: return an html tr formatted for wordpress admin forms 
	function slb_get_form_table_row(label, input , description){
		// build our tr html 
		var html = '<tr>'+
				   '<th scope="row"> <label> '+ label +'</label> </th>'+
				   '<td>'+ input;

				 if(description !== undefined)
				 {
				 	html += '<p class="description"> '+ description +'</p>';
				 }

			html += '</td></tr>';

		return html;
	}


	// hint: this function check to see if import_form_2 is valid
	function slb_form_2_is_valid(){

		var is_valid = true;

		//console.log($('[name="slb_import_rows[]"]:checked',$import_form_2).length);	

		// check if no subscriber are selected
		if($('[name="slb_import_rows[]"]:checked',$import_form_2).length == 0)
			is_valid = false;
	

		// check if no fname column is selected
		if($('[name="slb_fname_column"] option:selected', $import_form_2).val() == '')
			is_valid = false;
		
		

		// check if no lname column is selected
		if($('[name="slb_lname_column"] option:selected', $import_form_2).val() == '')
			is_valid = false;
		

		// check if no email column is selected
		if($('[name="slb_email_column"] option:selected', $import_form_2).val() == '')
			is_valid = false;
		
		
		


		return is_valid;
	}





});