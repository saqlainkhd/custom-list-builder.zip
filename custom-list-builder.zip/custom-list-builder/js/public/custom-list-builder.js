jQuery(document).ready(function($)
{
	// setup wp ajax url
	var wp_Ajax_url = document.location.protocol + '//' + document.location.host + "/wordpress/wp-admin/admin-ajax.php";

	// email capture action url
	var email_capture_url = wp_Ajax_url + '?action=slb_save_subscription';


	$('form#slb_register_form').bind('submit',function(){

		// get the Jquery form object
		$form = $(this); 

		// setup our form data for our jquery post
		var form_data = $form.serialize();

		// submit our form data with jquery
		$.ajax({
			'method' : 'post',
			'url' : email_capture_url,
			'data' : form_data,
			'data_type' : 'json',
			'cache' : false,
			'success' : function (data , textStatus)
			{
				console.log(data);

				response = jQuery.parseJSON(data);

				if(response.status == 1)
				{
					$form[0].reset();
					alert(response.message);
				}
				else{

					
					var msg = response.message + '\n' + response.error + '\n';
					$.each(response.errors, function(key,value){
						msg += '\n';
						msg += '- ' + value;
					});

					alert(msg);
				}
			},
			'error' : function(jqXHR, textStatus, errorThrown)
			{
					// ajax didnt worked
			}
		});

		// stop the form form submitting normally
		return false;



	});


	// email capture action url
	var unsubscribe_url = wp_Ajax_url + '?action=slb_unsubscribe';


	$(document).on('submit','form#slb_manage_subcriptions_form',function(){

		// get the Jquery form object
		$form = $(this); 

		// setup our form data for our jquery post
		var form_data = $form.serialize();

		// submit our form data with jquery
		$.ajax({
			'method' : 'post',
			'url' : unsubscribe_url,
			'data' : form_data,
			'data_type' : 'json',
			'cache' : false,
			'success' : function (data , textStatus)
			{
				console.log(data);

				response = jQuery.parseJSON(data);

				if(response.status == 1)
				{
					//  update form html
					 $form.replaceWith(response.html);


					alert(response.message);
				}
				else{

					
					var msg = response.message + '\n' + response.error + '\n';
					// $.each(response.errors, function(key,value){
					// 	msg += '\n';
					// 	msg += '- ' + value;
					// });

					alert(msg);
				}
			},
			'error' : function(jqXHR, textStatus, errorThrown)
			{
					// ajax didnt worked
			}
		});

		// stop the form form submitting normally
		return false;



	});

});
