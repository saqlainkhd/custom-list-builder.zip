=== Custom List Builder ===
Contributors: saqlainkhalid
Donate link: http://example.com/
Tags: Email, Subcribe , Email Subcribers , Email List , List Builder , Newsletter , MailChimp , opt-in
Requires at least: 4.0
Tested up to: 4.3
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Capture new subcribers , Reward subcriber with a custom download upon opt-in. Build Unlimited lists. Import and Export subscriber easily.

== Description ==

The Ultimate email list builder plugin for wordpress. Capture new subcribers , Reward subcriber with a custom download upon opt-in. Build Unlimited lists. Import and Export subscriber easily.

Some of the owesome feature include:

* Create Unlimited Email lists
* Capture Subscribers with custom forms Using a Shortcode
* Double Opt-in for confirming subscriptions
* User unsubcribe feature with a subscription manager
* Reward subscriber with an exclusive download when the opt-in
* Easily Export subscriber to a CSV
* Easily Import Subscriber from a CSV
* Automatically Email Subscribers when they signup and opt-in




== Installation ==

1. Unzip the plugin file 
2. Upload the folder 'custom-list-builder' and it's contents to the '/wp-content/plugins/' directory.
3. Active the plugin through the 'Plugins' menu in WordPress.
4. Use the 'List Builder' plugin menu and create the new 'Email List'
5. Copy the Shortcode (ex. [slb_form id="123"] ) next to your new email list and embed it anywhere in your website.
6. You will also need to create 3 new pages in Your WordPress website (see steps 7-9)
7. Create a new Page through the 'Page' menu in WordPress and Include the shortcode '[slb_confirm_subscription]' on this page. this is a page where subscribers will confirm their subscriptions.
8. Create aother Page through the 'Page' menu in WordPress and Include the shortcode '[slb_manage_subscription]' on this page. this is a page where subscribers will Manage subscriptions
9. Create one more Page through the 'Page' menu in WordPress and Include the shortcode '[slb_download_reward]' on this page. this is a page where subscribers will retrived their list rewards.
10. visit 'Plugin Options' in the 'List Builder'plugin menu and update the 'Manage Subscriptions. Page', 'Opt-In Page' and 'Download Reward Page' to point the appropriate pages you created in step 6.
11. Happy List Building!



== Frequently Asked Questions ==

= how to contact developer ? =

If you have any Question or Suggestion Regarding this Plugin feel free to shot me an email at support@saqlainkhalid.com



== Screenshots ==

1. Email List Page 
2. Edit Email List page
3. Subscriber page
4. Edit Subscriber page
5. Import Subscriber page 
6. Plugin Option page
7. Plugin Dashboard

== Changelog ==

= 1.0 =
* Updated tested versions to include WordPress 4.3
* Improved security


== Upgrade Notice ==

= 1.0 =
This Upgrade gets rids of 'Untested WordPress Version' notice on the plugin page for the user who've Upgraded to WordPress 4.3 


== About Me ==

As-salamu Alaykum /  Hello!

My name is Saqlain Khalid.

I was born and live in Karachi, Pakistan and In 2014, I completed my ACCP Certification from Aptech Shahrah-e-Faisal , karachi.

When I hit 20, I spent several years freelancing with the skills I picked up from terribly long nights of studying. Freelancing was difficult for me because being a salesman wasn't in my blood, but I enjoyed the coding parts! I primarily used PHP, MySQL, JS and CSS. Then jQuery , AnugulrJS and NodeJs a bit later.

